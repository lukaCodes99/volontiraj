package hr.tvz.volontiraj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VolontirajApplicationTests {

    @Test
    void contextLoads() {
    }

}
