package hr.tvz.volontiraj.model;

public enum EventCategory {
    PETS,
    PEOPLE,
    COMMUNITY,
    OTHER
}
